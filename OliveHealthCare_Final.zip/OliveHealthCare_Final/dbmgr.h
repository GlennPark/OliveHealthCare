﻿#ifndef DBMGR_H
#define DBMGR_H

#include "db.h"

/**
 * @brief The DBMgr class
 */
class DBMgr : public QObject
{
    Q_OBJECT
private:
    DB m_db;
    static DBMgr* m_instance;

public:
    static DBMgr* getInstance();

    Customer_list getCustomerList();                                         // Customer 정보 가져오기
    bool addCustomer(Customer info);                                         // Customer 추가
    bool updateCustomer(Customer info);                                      // Customer 정보 수정
    bool deleteCustomer(QString Cid);                                        // Customer 삭제
    Customer_list getCustomerList_search(QString field, QString value);      // Customer 검색

    Merchandise_list getMerchandiseList();                                   // Merchandise 정보 가져오기
    bool addMerchandise(Merchandise info);                                   // Merchandise 추가
    bool updateMerchandise(Merchandise info);                                // Merchandise 정보 수정
    bool deleteMerchandise(QString Mid);                                     // Merchandise 삭제
    Merchandise_list getMerchandiseList_search(QString field, QString value);// Merchandise 검색

    Purchase_list getPurchaseList();                                         // Purchase 정보 가져오기
    bool addPurchase(Purchase info);                                         // Purchase 추가
    bool deletePurchase(QString Pid);                                        // Purchase 삭제
    Purchase_list getPurchaseList_search(QString field, QString value);   // Purchase 검색

private:
    explicit DBMgr(QObject *parent = nullptr);
    ~DBMgr();
};

#endif // DBMGR_H
