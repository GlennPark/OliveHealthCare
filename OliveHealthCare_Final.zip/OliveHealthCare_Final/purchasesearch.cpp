﻿#include "purchasesearch.h"
#include "ui_purchasesearch.h"
#include "dbmgr.h"
#include <QDebug>

PurchaseSearch::PurchaseSearch(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PurchaseSearch)
{
    ui->setupUi(this);

    QStringList headerList;
    headerList << tr("PID")                 //
               << tr("CID")                 // 회원 Key
               << tr("MID")                 // 제품 Key
               << tr("BUYAMOUNT")           //
               << tr("SHOPDATE")            //
               //<< tr("CID")                // 회원 Key
               << tr("NAME")               // 회원 이름
               << tr("PHONE NUMBER")       // 회원 전화 번호
               << tr("EMAIL")              // 회원 이메일 주소
               << tr("DOMAIN")             // 회원 도메인 주소
               << tr("ADDRESS")            // 회원 거주지 주소
               << tr("FAVORITE")           // 회원 선호 항목
               << tr("AGE")                // 회원 연령
               << tr("GENDER")             // 회원 성별
               << tr("JOINDATE")           // 회원 가입 날짜
               //<< tr("MID")                 // 제품 Key
               << tr("MNAME")               // 제품명
               << tr("PRICE")               // 제품 가격
               << tr("QUANTITY")            // 제품 수량
               << tr("MADEIN")              // 제품 생산국가
               << tr("CATEGORY")            // 제품 유형
               << tr("DESCRIPTION")         // 제품 설명
               << tr("ENROLLDATE");         // 제품 등록 일자

    // 헤더 정보 적용
    ui->tableWidget->setColumnCount(headerList.size());
    ui->tableWidget->setHorizontalHeaderLabels(headerList);
    ui->tableWidget->resizeColumnsToContents();
}

PurchaseSearch::~PurchaseSearch()
{
    delete ui;
}

void PurchaseSearch::loadList()
{
    qDebug() << __FUNCTION__;
    QString searchType;
    if (ui->medicalPushButton->isChecked())
        searchType = "Medical";
    if (ui->healthpushButton->isChecked())
        searchType = "Health";
    if (ui->dietPushButton->isChecked())
        searchType = "Diet";

    Purchase_list plist = DBMgr::getInstance()->getPurchaseList();
    foreach (Purchase pinfo, plist)
    {
        // get customer data (Cid에 매칭되는 정보)
        Customer_list clist = DBMgr::getInstance()->getCustomerList_search("Cid", QString::number(pinfo.getCid()));
        if (clist.size() < 1)
            continue;

        // get merchandise data (Mid에 매칭되는 정보)
        Merchandise_list mlist = DBMgr::getInstance()->getMerchandiseList_search("Mid", QString::number(pinfo.getMid()));
        if (mlist.size() < 1)
            continue;

        Customer cInfo = clist.at(0);
        Merchandise mInfo = mlist.at(0);

        if (cInfo.getFavorite() != searchType)
            continue;

        if (mInfo.getCategory() != searchType)
            continue;

        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 0, new QTableWidgetItem(QString::number(pinfo.getPid())));          // Pid
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 1, new QTableWidgetItem(QString::number(pinfo.getCid())));          // Cid
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 2, new QTableWidgetItem(QString::number(pinfo.getMid())));          // Mid
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 3, new QTableWidgetItem(QString::number(pinfo.getBuyAmount())));    // BuyAmount
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 4, new QTableWidgetItem(pinfo.getShopDate()));                      // ShopDate

        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 5, new QTableWidgetItem(cInfo.getName()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 6, new QTableWidgetItem(cInfo.getPhoneNumber()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 7, new QTableWidgetItem(cInfo.getEmail()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 8, new QTableWidgetItem(cInfo.getDomain()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 9, new QTableWidgetItem(cInfo.getAddress()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 10, new QTableWidgetItem(cInfo.getFavorite()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 11, new QTableWidgetItem(QString::number(cInfo.getAge())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 12, new QTableWidgetItem(cInfo.getGender()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 13, new QTableWidgetItem(cInfo.getJoinDate()));

        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 14, new QTableWidgetItem(mInfo.getMname()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 15, new QTableWidgetItem(QString::number(mInfo.getPrice())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 16, new QTableWidgetItem(QString::number(mInfo.getQuantity())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 17, new QTableWidgetItem(mInfo.getMadein()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 18, new QTableWidgetItem(mInfo.getCategory()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 19, new QTableWidgetItem(mInfo.getDescription()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 20, new QTableWidgetItem(mInfo.getEnrollDate()));
    }

    ui->tableWidget->resizeColumnsToContents();
}

void PurchaseSearch::clearAllList()
{
    qDebug() << __FUNCTION__;
    while (ui->tableWidget->rowCount() > 0)
    {
        ui->tableWidget->removeRow(0);
    }
}

void PurchaseSearch::on_medicalPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

void PurchaseSearch::on_healthpushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

void PurchaseSearch::on_dietPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

