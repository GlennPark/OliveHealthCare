﻿#ifndef MERCHANDISEMANAGE_H
#define MERCHANDISEMANAGE_H

#include <QWidget>
#include "global.h"

namespace Ui {
class MerchandiseManage;
}

class MerchandiseManage : public QWidget
{
    Q_OBJECT

public:
    explicit MerchandiseManage(QWidget *parent = nullptr);
    ~MerchandiseManage();

    void loadList();                       // 리스트 불러오기
    void clearAllList();                   // 리스트 모두 제거
    Merchandise_list getTableList();

private slots:
    void on_addPushButton_clicked();        // 추가버튼
    void on_modifyPushButton_clicked();     // 수정버튼
    void on_deletePushButton_clicked();     // 리스트에 선택된 정보 삭제
    void on_refreshPushButton_clicked();    // DB에서 정보 다시가져오기
    void on_searchPushButton_clicked();     // 검색버튼
    void on_tableWidget_clicked(const QModelIndex &index);      // list 클릭

private:
    Ui::MerchandiseManage *ui;

private:

    // 제품 키값 변수
    int makeMid();
};

#endif // MERCHANDISEMANAGE_H
