﻿#ifndef CUSTOMERSEARCH_H
#define CUSTOMERSEARCH_H

#include <QWidget>

namespace Ui {
class CustomerSearch;
}

class CustomerSearch : public QWidget
{
    Q_OBJECT

public:
    explicit CustomerSearch(QWidget *parent = nullptr);
    ~CustomerSearch();

    void loadList();                       // 리스트 불러오기
    void clearAllList();                   // 리스트 모두 제거

private slots:
    void on_medicalPushButton_clicked();
    void on_healthpushButton_clicked();
    void on_dietPushButton_clicked();

private:
    Ui::CustomerSearch *ui;
};

#endif // CUSTOMERSEARCH_H
