﻿#include "merchandisesearch.h"
#include "ui_merchandisesearch.h"
#include "dbmgr.h"
#include <QDebug>

MerchandiseSearch::MerchandiseSearch(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MerchandiseSearch)
{
    ui->setupUi(this);

    QStringList headerList;
    headerList << tr("MID")                 // 제품 Key
               << tr("MNAME")               // 제품명
               << tr("PRICE")               // 제품 가격
               << tr("QUANTITY")            // 제품 수량
               << tr("MADEIN")              // 제품 생산국가
               << tr("CATEGORY")            // 제품 유형
               << tr("DESCRIPTION")         // 제품 설명
               << tr("ENROLLDATE");         // 제품 등록 일자

    // 헤더 정보 적용
    ui->tableWidget->setColumnCount(headerList.size());
    ui->tableWidget->setHorizontalHeaderLabels(headerList);
    ui->tableWidget->resizeColumnsToContents();
}

MerchandiseSearch::~MerchandiseSearch()
{
    delete ui;
}

void MerchandiseSearch::loadList()
{
    qDebug() << __FUNCTION__;
    QString categoryType;
    if (ui->medicalPushButton->isChecked())
        categoryType = "Medical";
    if (ui->healthpushButton->isChecked())
        categoryType = "Health";
    if (ui->dietPushButton->isChecked())
        categoryType = "Diet";

    Merchandise_list list = DBMgr::getInstance()->getMerchandiseList_search("category", categoryType);
    foreach (Merchandise info, list)
    {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 0, new QTableWidgetItem(QString::number(info.getMid())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 1, new QTableWidgetItem(info.getMname()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 2, new QTableWidgetItem(QString::number(info.getPrice())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 3, new QTableWidgetItem(QString::number(info.getQuantity())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 4, new QTableWidgetItem(info.getMadein()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 5, new QTableWidgetItem(info.getCategory()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 6, new QTableWidgetItem(info.getDescription()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 7, new QTableWidgetItem(info.getEnrollDate()));
    }

    ui->tableWidget->resizeColumnsToContents();
}

void MerchandiseSearch::clearAllList()
{
    qDebug() << __FUNCTION__;
    while (ui->tableWidget->rowCount() > 0)
    {
        ui->tableWidget->removeRow(0);
    }
}

void MerchandiseSearch::on_medicalPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

void MerchandiseSearch::on_healthpushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

void MerchandiseSearch::on_dietPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

