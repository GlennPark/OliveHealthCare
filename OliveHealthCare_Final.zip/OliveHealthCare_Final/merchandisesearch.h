﻿#ifndef MERCHANDISESEARCH_H
#define MERCHANDISESEARCH_H

#include <QWidget>

namespace Ui {
class MerchandiseSearch;
}

class MerchandiseSearch : public QWidget
{
    Q_OBJECT

public:
    explicit MerchandiseSearch(QWidget *parent = nullptr);
    ~MerchandiseSearch();

    void loadList();                       // 리스트 불러오기
    void clearAllList();                   // 리스트 모두 제거

private slots:
    void on_medicalPushButton_clicked();
    void on_healthpushButton_clicked();
    void on_dietPushButton_clicked();

private:
    Ui::MerchandiseSearch *ui;
};

#endif // MERCHANDISESEARCH_H
