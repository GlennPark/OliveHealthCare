﻿#include "db.h"
#include <QDebug>
#include <QApplication>

DB::DB(QObject *parent) :
    QObject(parent)
{
    init();
}

DB::~DB()
{
    close();
}

bool DB::select(Customer_list& list)
{
    if (!m_sqlDB.isOpen())
        return false;

    QString queryStr = "SELECT * FROM 'customer'";
    QSqlQuery query(queryStr, m_sqlDB);

    while (query.next())
    {
        Customer info;
        info.setCid(query.value("Cid").toInt());
        info.setName(query.value("name").toString());
        info.setPhoneNumber(query.value("phoneNumber").toString());
        info.setEmail(query.value("email").toString());
        info.setDomain(query.value("domain").toString());
        info.setAddress(query.value("address").toString());
        info.setFavorite(query.value("favorite").toString());
        info.setAge(query.value("age").toInt());
        info.setGender(query.value("gender").toString());
        info.setJoinDate(query.value("joinDate").toString());

        list.append(info);
    }

    return true;
}

bool DB::select(Customer_list& list, QString queryStr)
{
    if (!m_sqlDB.isOpen())
        return false;

    QSqlQuery query(queryStr, m_sqlDB);

    while (query.next())
    {
        Customer info;
        info.setCid(query.value("Cid").toInt());
        info.setName(query.value("name").toString());
        info.setPhoneNumber(query.value("phoneNumber").toString());
        info.setEmail(query.value("email").toString());
        info.setDomain(query.value("domain").toString());
        info.setAddress(query.value("address").toString());
        info.setFavorite(query.value("favorite").toString());
        info.setAge(query.value("age").toInt());
        info.setGender(query.value("gender").toString());
        info.setJoinDate(query.value("joinDate").toString());

        list.append(info);
    }

    return true;
}

bool DB::select(Customer_list& list, QString field, QString value)
{
    if (!m_sqlDB.isOpen())
        return false;

    QString query = "SELECT * FROM 'customer' WHERE " + field + "='" + value + "'";

    select(list, query);

    return true;
}

bool DB::insert(Customer info)
{
    QSqlQuery query(m_sqlDB);
    query.prepare("INSERT INTO 'customer' (Cid, name, phoneNumber, email, domain, address, favorite, age, gender, joinDate)"
                  "VALUES (:Cid, :name, :phoneNumber, :email, :domain, :address, :favorite, :age, :gender, :joinDate)");

    query.bindValue(":Cid", info.getCid());
    query.bindValue(":name", info.getName());
    query.bindValue(":phoneNumber", info.getPhoneNumber());
    query.bindValue(":email", info.getEmail());
    query.bindValue(":domain", info.getDomain());
    query.bindValue(":address", info.getAddress());
    query.bindValue(":favorite", info.getFavorite());
    query.bindValue(":age", info.getAge());
    query.bindValue(":gender", info.getGender());
    query.bindValue(":joinDate", info.getJoinDate());

    if (!query.exec())
    {
        qDebug() << "DB::insert fail..1";
        return false;
    }

    return true;
}

bool DB::update(Customer info)
{
    QSqlQuery query(m_sqlDB);
    query.prepare("UPDATE 'customer' SET "
                  "name=:name,"
                  "phoneNumber=:phoneNumber,"
                  "email=:email,"
                  "domain=:domain,"
                  "address=:address,"
                  "favorite=:favorite,"
                  "age=:age,"
                  "gender=:gender,"
                  "joinDate=:joinDate"
                  " WHERE Cid=:W_value"
                  );

    query.bindValue(":name",        info.getName());
    query.bindValue(":phoneNumber", info.getPhoneNumber());
    query.bindValue(":email",       info.getEmail());
    query.bindValue(":domain",      info.getDomain());
    query.bindValue(":address",     info.getAddress());
    query.bindValue(":favorite",    info.getFavorite());
    query.bindValue(":age",         info.getAge());
    query.bindValue(":gender",      info.getGender());
    query.bindValue(":joinDate",    info.getJoinDate());
    query.bindValue(":W_value",     info.getCid());

    if (!query.exec())
    {
        qDebug() << "DB::update fail..1";
        return false;
    }

    return true;
}

bool DB::select(Merchandise_list& list)
{
    if (!m_sqlDB.isOpen())
        return false;

    QString queryStr = "SELECT * FROM 'merchandise'";
    QSqlQuery query(queryStr, m_sqlDB);

    while (query.next())
    {
        Merchandise info;
        info.setMid(query.value("Mid").toInt());
        info.setMname(query.value("mname").toString());
        info.setPrice(query.value("price").toInt());
        info.setQuantity(query.value("quantity").toInt());
        info.setMadein(query.value("madein").toString());
        info.setCategory(query.value("category").toString());
        info.setDescription(query.value("description").toString());
        info.setEnrollDate(query.value("enrollDate").toString());

        list.append(info);
    }

    return true;
}

bool DB::select(Merchandise_list& list, QString queryStr)
{
    if (!m_sqlDB.isOpen())
        return false;

    QSqlQuery query(queryStr, m_sqlDB);

    while (query.next())
    {
        Merchandise info;
        info.setMid(query.value("Mid").toInt());
        info.setMname(query.value("mname").toString());
        info.setPrice(query.value("price").toInt());
        info.setQuantity(query.value("quantity").toInt());
        info.setMadein(query.value("madein").toString());
        info.setCategory(query.value("category").toString());
        info.setDescription(query.value("description").toString());
        info.setEnrollDate(query.value("enrollDate").toString());

        list.append(info);
    }

    return true;
}

bool DB::select(Merchandise_list& list, QString field, QString value)
{
    if (!m_sqlDB.isOpen())
        return false;

    QString query = "SELECT * FROM 'merchandise' WHERE " + field + "='" + value + "'";

    select(list, query);

    return true;
}

bool DB::insert(Merchandise info)
{
    QSqlQuery query(m_sqlDB);
    query.prepare("INSERT INTO 'merchandise' (Mid, mname, price, quantity, madein, category, description, enrollDate)"
                  "VALUES (:Mid, :mname, :price, :quantity, :madein, :category, :description, :enrollDate)");

    query.bindValue(":Mid", info.getMid());
    query.bindValue(":mname", info.getMname());
    query.bindValue(":price", info.getPrice());
    query.bindValue(":quantity", info.getQuantity());
    query.bindValue(":madein", info.getMadein());
    query.bindValue(":category", info.getCategory());
    query.bindValue(":description", info.getDescription());
    query.bindValue(":enrollDate", info.getEnrollDate());

    if (!query.exec())
    {
        qDebug() << "DB::insert fail..1";
        return false;
    }

    return true;
}

bool DB::update(Merchandise info)
{
    QSqlQuery query(m_sqlDB);
    query.prepare("UPDATE 'merchandise' SET "
                  "mname=:mname,"
                  "price=:price,"
                  "quantity=:quantity,"
                  "madein=:madein,"
                  "category=:category,"
                  "description=:description,"
                  "enrollDate=:enrollDate"
                  " WHERE Mid=:W_value"
                  );

    query.bindValue(":mname",       info.getMname());
    query.bindValue(":price",       info.getPrice());
    query.bindValue(":quantity",    info.getQuantity());
    query.bindValue(":madein",      info.getMadein());
    query.bindValue(":category",    info.getCategory());
    query.bindValue(":description", info.getDescription());
    query.bindValue(":enrollDate",  info.getEnrollDate());
    query.bindValue(":W_value",     info.getMid());

    if (!query.exec())
    {
        qDebug() << "DB::update fail..1";
        return false;
    }

    return true;
}

bool DB::select(Purchase_list& list)
{
    if (!m_sqlDB.isOpen())
        return false;

    QString queryStr = "SELECT * FROM 'purchase'";
    QSqlQuery query(queryStr, m_sqlDB);

    while (query.next())
    {
        Purchase info;
        info.setPid(query.value("Pid").toInt());
        info.setCid(query.value("Cid").toInt());
        info.setMid(query.value("Mid").toInt());
        info.setBuyAmount(query.value("buyAmount").toInt());
        info.setShopDate(query.value("shopDate").toString());

        list.append(info);
    }

    return true;
}

bool DB::select(Purchase_list& list, QString queryStr)
{
    if (!m_sqlDB.isOpen())
        return false;

    QSqlQuery query(queryStr, m_sqlDB);

    while (query.next())
    {
        Purchase info;
        info.setPid(query.value("Pid").toInt());
        info.setCid(query.value("Cid").toInt());
        info.setMid(query.value("Mid").toInt());
        info.setBuyAmount(query.value("buyAmount").toInt());
        info.setShopDate(query.value("shopDate").toString());

        list.append(info);
    }

    return true;
}

bool DB::select(Purchase_list& list, QString field, QString value)
{
    if (!m_sqlDB.isOpen())
        return false;

    QString query = "SELECT * FROM 'purchase' WHERE " + field + "='" + value + "'";

    select(list, query);

    return true;
}

bool DB::insert(Purchase info)
{
    QSqlQuery query(m_sqlDB);
    query.prepare("INSERT INTO 'purchase' (Pid, Cid, Mid, buyAmount, shopDate)"
                  "VALUES (:Pid, :Cid, :Mid, :buyAmount, :shopDate)");

    query.bindValue(":Pid", info.getPid());
    query.bindValue(":Cid", info.getCid());
    query.bindValue(":Mid", info.getMid());
    query.bindValue(":buyAmount", info.getBuyAmount());
    query.bindValue(":shopDate", info.getShopDate());

    if (!query.exec())
    {
        qDebug() << "DB::insert fail..1";
        return false;
    }

    return true;
}

bool DB::deleteAll(QString table)
{
    QString queryStr = "DELETE FROM '" + table + "'";
    QSqlQuery query(m_sqlDB);
    query.prepare(queryStr);

    if (!query.exec())
    {
        qDebug() << "DB::deleteAll fail queryStr: " << queryStr;
        return false;
    }

    return true;
}

bool DB::deleteRecord(QString table, QString field, QString value)
{
    QString queryStr = "DELETE FROM '" + table + "' WHERE " + field + "='" + value + "'";
    QSqlQuery query(m_sqlDB);
    query.prepare(queryStr);

    if (!query.exec())
    {
        qDebug() << "DB::deleteRecord fail queryStr: " << queryStr;
        return false;
    }

    return true;
}

int DB::count(QString table)
{
    QString queryStr = "SELECT COUNT(*) FROM '" + table + "'";
    QSqlQuery query(m_sqlDB);
    query.prepare(queryStr);

    if (!query.exec())
    {
        qDebug() << "DB::count fail queryStr: " << queryStr;
        return -1;
    }

    query.first();
    return query.value(0).toInt();
}
void DB::init()
{
    m_dbFilePath = qApp->applicationDirPath() + "/database.db";
    qDebug() << "DB::init path : " << m_dbFilePath;

    m_sqlDB = QSqlDatabase::addDatabase("QSQLITE");    // kind database
    m_sqlDB.setDatabaseName(m_dbFilePath);             // database file name, path
    if(m_sqlDB.open())                                 // File open or make
    {
        qDebug() << "DB::init open DB file - OK : " << m_dbFilePath;
    }
    else
    {
        qDebug() << "DB::init open DB file - Fail";
        emit error(tr("Failed to create DB file."));
        return;
    }

    // create table
    // 테이블 생성
    createCustomer();
    createMerchandise();
    createPurchase();
}

void DB::close()
{
    if (!m_sqlDB.isOpen())
    {
        return;
    }

    m_sqlDB.close();
}

void DB::createCustomer()
{
    QSqlQuery query(m_sqlDB);
    QString queryStr;
    queryStr =
            "CREATE TABLE IF NOT EXISTS customer"
            "(Cid INTEGER PRIMARY KEY, "
            "name VARCHAR(20), "
            "phoneNumber VARCHAR(100), "
            "email VARCHAR(100), "
            "domain VARCHAR(100), "
            "address VARCHAR(200), "
            "favorite VARCHAR(100), "
            "age INTEGER, "
            "gender VARCHAR(50), "
            "joinDate VARCHAR(20));";

    if (!query.exec(queryStr))
    {
        qDebug() << "DB::createCustomer failed to queryStr : " << queryStr;
    }
}

void DB::createMerchandise()
{
    QSqlQuery query(m_sqlDB);
    QString queryStr;
    queryStr =
            "CREATE TABLE IF NOT EXISTS merchandise"
            "(Mid INTEGER PRIMARY KEY, "
            "mname VARCHAR(20), "
            "price INTEGER, "
            "quantity INTEGER, "
            "madein VARCHAR(100), "
            "category VARCHAR(100), "
            "description VARCHAR(500), "
            "enrollDate VARCHAR(20));";

    if (!query.exec(queryStr))
    {
        qDebug() << "DB::createMerchandise failed to queryStr : " << queryStr;
    }
}

void DB::createPurchase()
{
    QSqlQuery query(m_sqlDB);
    QString queryStr;
    queryStr =
            "CREATE TABLE IF NOT EXISTS purchase"
            "(Pid 'INTEGER PRIMARY KEY', "
            "Cid 'INTEGER PRIMARY KEY', "
            "Mid 'INTEGER PRIMARY KEY', "
            "buyAmount INTEGER, "
            "shopDate VARCHAR(20));";

    if (!query.exec(queryStr))
    {
        qDebug() << "DB::createPurchase failed to queryStr : " << queryStr;
    }
}
