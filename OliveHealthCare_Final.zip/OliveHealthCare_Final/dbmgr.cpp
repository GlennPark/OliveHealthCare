﻿#include "dbmgr.h"

DBMgr* DBMgr::m_instance = nullptr;

DBMgr::DBMgr(QObject *parent) :
    QObject(parent)
{

}

DBMgr::~DBMgr()
{

}

DBMgr* DBMgr::getInstance()
{
    if (m_instance == nullptr)
    {
        m_instance = new DBMgr();
    }

    return m_instance;
}

Customer_list DBMgr::getCustomerList()
{
    Customer_list list;
    m_db.select(list);
    return list;
}

bool DBMgr::addCustomer(Customer info)
{
    return m_db.insert(info);
}

bool DBMgr::updateCustomer(Customer info)
{
    return m_db.update(info);
}

bool DBMgr::deleteCustomer(QString Cid)
{
    return m_db.deleteRecord("customer", "Cid", Cid);
}

Customer_list DBMgr::getCustomerList_search(QString field, QString value)
{
    Customer_list list;
    m_db.select(list, field, value);
    return list;
}

Merchandise_list DBMgr::getMerchandiseList()
{
    Merchandise_list list;
    m_db.select(list);
    return list;
}

bool DBMgr::addMerchandise(Merchandise info)
{
    return m_db.insert(info);
}

bool DBMgr::updateMerchandise(Merchandise info)
{
    return m_db.update(info);
}

bool DBMgr::deleteMerchandise(QString Mid)
{
    return m_db.deleteRecord("merchandise", "Mid", Mid);
}

Merchandise_list DBMgr::getMerchandiseList_search(QString field, QString value)
{
    Merchandise_list list;
    m_db.select(list, field, value);
    return list;
}

Purchase_list DBMgr::getPurchaseList()
{
    Purchase_list list;
    m_db.select(list);
    return list;
}

bool DBMgr::addPurchase(Purchase info)
{
    return m_db.insert(info);
}

bool DBMgr::deletePurchase(QString Pid)
{
    return m_db.deleteRecord("purchase", "Pid", Pid);
}

Purchase_list DBMgr::getPurchaseList_search(QString field, QString value)
{
    Purchase_list list;
    m_db.select(list, field, value);
    return list;
}









