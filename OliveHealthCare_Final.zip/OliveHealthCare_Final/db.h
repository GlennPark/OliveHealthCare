﻿#ifndef DB_H
#define DB_H
#include "global.h"
#include <QObject>
#include <QSqlQuery>

class DB : public QObject
{
    Q_OBJECT
private:
    QSqlDatabase m_sqlDB;
    QString m_dbFilePath;

public:
    explicit DB(QObject *parent = nullptr);
    ~DB();

    bool select(Customer_list& list);
    bool select(Customer_list& list, QString queryStr);
    bool select(Customer_list& list, QString field, QString value);
    bool insert(Customer info);
    bool update(Customer info);

    bool select(Merchandise_list& list);
    bool select(Merchandise_list& list, QString queryStr);
    bool select(Merchandise_list& list, QString field, QString value);
    bool insert(Merchandise info);
    bool update(Merchandise info);

    bool select(Purchase_list& list);
    bool select(Purchase_list& list, QString queryStr);
    bool select(Purchase_list& list, QString field, QString value);
    bool insert(Purchase info);

    bool deleteAll(QString table);
    bool deleteRecord(QString table, QString field, QString value);

    int count(QString table);

private:
    void init();
    void close();
    void createCustomer();
    void createMerchandise();
    void createPurchase();

signals:
    void error(QString msg);
};

#endif // DB_H
