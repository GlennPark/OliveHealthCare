﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class CustomerManage;
class CustomerSearch;
class MerchandiseManage;
class MerchandiseSearch;
class PurchaseManage;
class PurchaseSearch;
class ChattingServer;
class ChattingClient;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_customerManage_clicked();
    void on_pushButton_customerSearch_clicked();
    void on_pushButton_merchandiseManage_clicked();
    void on_pushButton_merchandiseSearch_clicked();
    void on_pushButton_purchaseManage_clicked();
    void on_pushButton_purchaseSearch_clicked();
    void on_pushButton_chatServer_clicked();
    void on_pushButton_customerChat_clicked();
    void on_pushButton_quit_clicked();

    void on_pushButton_color1_clicked();
    void on_pushButton_color2_clicked();
    void on_pushButton_color3_clicked();

private:
    Ui::MainWindow *ui;
    CustomerManage* customerManage;
    CustomerSearch* customerSearch;
    MerchandiseManage* merchandiseManage;
    MerchandiseSearch* merchandiseSearch;
    PurchaseManage* purchaseManage;
    PurchaseSearch* purchaseSearch;
    ChattingServer* chattingServer;
    ChattingClient* chattingClient;

private slots:
    void slot_getCustomerTable_from_purchaseManage();
    void slot_getMerchandiseTable_from_purchaseManage();
};
#endif // MAINWINDOW_H
