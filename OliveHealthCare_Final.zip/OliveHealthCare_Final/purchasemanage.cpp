﻿#include "purchasemanage.h"
#include "ui_purchasemanage.h"
#include "dbmgr.h"
#include <QDebug>

PurchaseManage::PurchaseManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PurchaseManage)
{
    ui->setupUi(this);

    QStringList headerList;
    headerList << tr("PID")                 //
               << tr("CID")                 // 회원 Key
               << tr("MID")                 // 제품 Key
               << tr("BUYAMOUNT")           //
               << tr("SHOPDATE")            //
               //<< tr("CID")                // 회원 Key
               << tr("NAME")               // 회원 이름
               << tr("PHONE NUMBER")       // 회원 전화 번호
               << tr("EMAIL")              // 회원 이메일 주소
               << tr("DOMAIN")             // 회원 도메인 주소
               << tr("ADDRESS")            // 회원 거주지 주소
               << tr("FAVORITE")           // 회원 선호 항목
               << tr("AGE")                // 회원 연령
               << tr("GENDER")             // 회원 성별
               << tr("JOINDATE")           // 회원 가입 날짜
               //<< tr("MID")                 // 제품 Key
               << tr("MNAME")               // 제품명
               << tr("PRICE")               // 제품 가격
               << tr("QUANTITY")            // 제품 수량
               << tr("MADEIN")              // 제품 생산국가
               << tr("CATEGORY")            // 제품 유형
               << tr("DESCRIPTION")         // 제품 설명
               << tr("ENROLLDATE");         // 제품 등록 일자

    // 헤더 정보 적용
    ui->tableWidget->setColumnCount(headerList.size());
    ui->tableWidget->setHorizontalHeaderLabels(headerList);
    ui->tableWidget->resizeColumnsToContents();
    ui->tableWidget_search->setColumnCount(headerList.size());
    ui->tableWidget_search->setHorizontalHeaderLabels(headerList);
    ui->tableWidget_search->resizeColumnsToContents();

    // load purchase db
    loadList();
}

PurchaseManage::~PurchaseManage()
{
    delete ui;
}

void PurchaseManage::loadList()
{
    qDebug() << __FUNCTION__;
    Purchase_list plist = DBMgr::getInstance()->getPurchaseList();
    foreach (Purchase pinfo, plist)
    {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 0, new QTableWidgetItem(QString::number(pinfo.getPid())));          // Pid
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 1, new QTableWidgetItem(QString::number(pinfo.getCid())));          // Cid
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 2, new QTableWidgetItem(QString::number(pinfo.getMid())));          // Mid
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 3, new QTableWidgetItem(QString::number(pinfo.getBuyAmount())));    // BuyAmount
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 4, new QTableWidgetItem(pinfo.getShopDate()));                      // ShopDate

        // get customer data (Cid에 매칭되는 정보)
        Customer_list clist = DBMgr::getInstance()->getCustomerList_search("Cid", QString::number(pinfo.getCid()));
        if (clist.size() > 0)
        {
            Customer cInfo = clist.at(0);
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 5, new QTableWidgetItem(cInfo.getName()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 6, new QTableWidgetItem(cInfo.getPhoneNumber()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 7, new QTableWidgetItem(cInfo.getEmail()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 8, new QTableWidgetItem(cInfo.getDomain()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 9, new QTableWidgetItem(cInfo.getAddress()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 10, new QTableWidgetItem(cInfo.getFavorite()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 11, new QTableWidgetItem(QString::number(cInfo.getAge())));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 12, new QTableWidgetItem(cInfo.getGender()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 13, new QTableWidgetItem(cInfo.getJoinDate()));
        }

        // get merchandise data (Mid에 매칭되는 정보)
        Merchandise_list mlist = DBMgr::getInstance()->getMerchandiseList_search("Mid", QString::number(pinfo.getMid()));
        if (mlist.size() > 0)
        {
            Merchandise mInfo = mlist.at(0);
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 14, new QTableWidgetItem(mInfo.getMname()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 15, new QTableWidgetItem(QString::number(mInfo.getPrice())));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 16, new QTableWidgetItem(QString::number(mInfo.getQuantity())));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 17, new QTableWidgetItem(mInfo.getMadein()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 18, new QTableWidgetItem(mInfo.getCategory()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 19, new QTableWidgetItem(mInfo.getDescription()));
            ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 20, new QTableWidgetItem(mInfo.getEnrollDate()));
        }
    }

    ui->tableWidget->resizeColumnsToContents();
}

void PurchaseManage::clearAllList()
{
    qDebug() << __FUNCTION__;

    while (ui->tableWidget->rowCount() > 0)
    {
        ui->tableWidget->removeRow(0);
    }
}

void PurchaseManage::setCustomerTableList(Customer_list cList)
{
    foreach (Customer info, cList)
    {
        qDebug() << __FUNCTION__
                 << info.getCid()
                 << info.getName()
                 << info.getPhoneNumber()
                 << info.getEmail()
                 << info.getDomain()
                 << info.getAddress()
                 << info.getFavorite()
                 << info.getAge()
                 << info.getGender()
                 << info.getJoinDate();
    }
}

void PurchaseManage::setMerchandiseTableList(Merchandise_list mList)
{
    foreach (Merchandise info, mList)
    {
        qDebug() << __FUNCTION__
                 << info.getMid()
                 << info.getMname()
                 << info.getPrice()
                 << info.getQuantity()
                 << info.getMadein()
                 << info.getCategory()
                 << info.getDescription()
                 << info.getEnrollDate();
    }
}

void PurchaseManage::on_addPushButton_clicked()
{
    // 항목 별 자료형 설정
    int Pid = makePid( );
    int Cid = 0, Mid = 0, buyAmount;
    QString shopDate;

    // 항목별 ui 에 입력된 내용을 자료형에 따라 저장한다
    ui->PidLineEdit->setText(QString::number(Pid));
    Cid = ui->CidLineEdit->text().toInt();
    Mid = ui->MidLineEdit->text().toInt();
    buyAmount = ui->buyAmountSpinBox->value();
    shopDate = ui->shopDateEdit->date().toString("yyyyMMdd");

    qDebug() << __FUNCTION__
             << "Pid: "   << Pid
             << "Cid: " << Cid
             << "Mid: " << Mid
             << "buyAmount: " << buyAmount
             << "shopDate: " << shopDate;

    // Mid quantity 수량 정보 가져오기
    Merchandise_list mList = DBMgr::getInstance()->getMerchandiseList_search("Mid", QString::number(Mid));
    if (mList.size() < 1)
        return;

    Merchandise mInfo = mList.at(0);
    int quantity = mInfo.getQuantity();
    qDebug() << __FUNCTION__
             << "Mid: " << Mid
             << "quantity: " << quantity
             << "buyAmount: " << buyAmount;
    // 구매후 차감된 수량을 db에 업데이트
    int value = quantity - buyAmount;
    mInfo.setQuantity(value);
    DBMgr::getInstance()->updateMerchandise(mInfo);

    Purchase info;
    info.setPid(Pid);
    info.setCid(Cid);
    info.setMid(Mid);
    info.setBuyAmount(buyAmount);
    info.setShopDate(shopDate);

    DBMgr::getInstance()->addPurchase(info);     // DB에 추가

    // reload
    on_refreshPushButton_clicked();
}

void PurchaseManage::on_refreshPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    // list all clear
    clearAllList();

    // load all list
    loadList();
}

void PurchaseManage::on_deletePushButton_clicked()
{
    qDebug() << __FUNCTION__;
    QItemSelectionModel *select = ui->tableWidget->selectionModel();
    bool isSelect = select->hasSelection();                  //check if has selection
    if (!isSelect)
        return;

    QModelIndexList selectedList = select->selectedRows();   // return selected row(s)

    qDebug() << __FUNCTION__ << isSelect << selectedList;
    for(int i=0; i< selectedList.count(); i++)
    {
        QModelIndex index = selectedList.at(i);
        QTableWidgetItem* delItem = ui->tableWidget->item(index.row(), 0);
        QString Pid = delItem->text();
        DBMgr::getInstance()->deletePurchase(Pid);
        qDebug() << __FUNCTION__ << "delete Pid: " << Pid;

        ui->tableWidget->removeRow(index.row());            // 선택된 row 테이블에서 삭제
    }
}

void PurchaseManage::on_searchPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    QString searchType = ui->searchComboBox->currentText();
    QString searchText = ui->searchLineEdit->text();
    qDebug() << __FUNCTION__ << searchType << searchText;

    if (searchText.isEmpty())
        return;

    // clear all search list
    while (ui->tableWidget_search->rowCount() > 0)
    {
        ui->tableWidget_search->removeRow(0);
    }

    Purchase_list plist = DBMgr::getInstance()->getPurchaseList_search(searchType, searchText);
    foreach (Purchase pinfo, plist)
    {
        ui->tableWidget_search->insertRow(ui->tableWidget_search->rowCount());
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 0, new QTableWidgetItem(QString::number(pinfo.getPid())));          // Pid
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 1, new QTableWidgetItem(QString::number(pinfo.getCid())));          // Cid
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 2, new QTableWidgetItem(QString::number(pinfo.getMid())));          // Mid
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 3, new QTableWidgetItem(QString::number(pinfo.getBuyAmount())));    // BuyAmount
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 4, new QTableWidgetItem(pinfo.getShopDate()));                      // ShopDate

        // get customer data (Cid에 매칭되는 정보)
        Customer_list clist = DBMgr::getInstance()->getCustomerList_search("Cid", QString::number(pinfo.getCid()));
        if (clist.size() > 0)
        {
            Customer cInfo = clist.at(0);
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 5, new QTableWidgetItem(cInfo.getName()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 6, new QTableWidgetItem(cInfo.getPhoneNumber()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 7, new QTableWidgetItem(cInfo.getEmail()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 8, new QTableWidgetItem(cInfo.getDomain()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 9, new QTableWidgetItem(cInfo.getAddress()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 10, new QTableWidgetItem(cInfo.getFavorite()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 11, new QTableWidgetItem(QString::number(cInfo.getAge())));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 12, new QTableWidgetItem(cInfo.getGender()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 13, new QTableWidgetItem(cInfo.getJoinDate()));
        }

        // get merchandise data (Mid에 매칭되는 정보)
        Merchandise_list mlist = DBMgr::getInstance()->getMerchandiseList_search("Mid", QString::number(pinfo.getMid()));
        if (mlist.size() > 0)
        {
            Merchandise mInfo = mlist.at(0);
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 14, new QTableWidgetItem(mInfo.getMname()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 15, new QTableWidgetItem(QString::number(mInfo.getPrice())));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 16, new QTableWidgetItem(QString::number(mInfo.getQuantity())));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 17, new QTableWidgetItem(mInfo.getMadein()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 18, new QTableWidgetItem(mInfo.getCategory()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 19, new QTableWidgetItem(mInfo.getDescription()));
            ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 20, new QTableWidgetItem(mInfo.getEnrollDate()));
        }
    }

    ui->tableWidget_search->resizeColumnsToContents();
}

int PurchaseManage::makePid()
{
    qDebug() << __FUNCTION__;
    int rtn = 0;
    Purchase_list list = DBMgr::getInstance()->getPurchaseList();
    if (list.size() < 1)
        return 0;
    Purchase info = list.at(list.count()-1);
    rtn = info.getPid()+1;
    return rtn;
}


void PurchaseManage::on_tableWidget_clicked(const QModelIndex &index)
{
    qDebug() << __FUNCTION__;
    QTableWidgetItem *item;
    item = ui->tableWidget->item(index.row(), 3);
    if (!item)
        return;
    if (item->text().isEmpty())
        return;

    item = ui->tableWidget->item(index.row(), 15);
    if (!item)
        return;
    if (item->text().isEmpty())
        return;

    int buyAcount = ui->tableWidget->item(index.row(), 3)->text().toInt();
    int price = ui->tableWidget->item(index.row(), 15)->text().toInt();
    ui->totalPriceLineEdit->setText(QString::number(buyAcount*price));
}

void PurchaseManage::on_pushButton_get_customer_table_clicked()
{
    qDebug() << __FUNCTION__;
    emit getCustomerTable();
}

void PurchaseManage::on_pushButton_get_merchandise_table_clicked()
{
    qDebug() << __FUNCTION__;
    emit getMerchandiseTable();
}

