﻿#ifndef GLOBAL_H
#define GLOBAL_H

#include <QString>
#include <QDebug>

class Customer
{
public:
    int Cid;
    QString name;
    QString phoneNumber;
    QString email;
    QString domain;
    QString address;
    QString favorite;
    int age;
    QString gender;
    QString joinDate;

public:
    Customer()
    {
        Cid = 0;
        age = 0;
    }

public:

    int getCid() const;
    void setCid(int newCid);
    const QString& getName() const;
    void setName(const QString& newName);
    const QString& getPhoneNumber() const;
    void setPhoneNumber(const QString& newPhoneNumber);
    const QString& getEmail() const;
    void setEmail(const QString& newEmail);
    const QString& getDomain() const;
    void setDomain(const QString& newDomain);
    const QString& getAddress() const;
    void setAddress(const QString& newAddress);
    const QString& getFavorite() const;
    void setFavorite(const QString& newFavorite);
    int getAge() const;
    void setAge(int newAge);
    const QString& getGender() const;
    void setGender(const QString& newGender);
    const QString& getJoinDate() const;
    void setJoinDate(const QString& newJoinDate);
};

inline const QString& Customer::getName() const
{
    return name;
}

inline void Customer::setName(const QString& newName)
{
    name = newName;
}

inline const QString& Customer::getPhoneNumber() const
{
    return phoneNumber;
}

inline void Customer::setPhoneNumber(const QString& newPhoneNumber)
{
    phoneNumber = newPhoneNumber;
}

inline const QString& Customer::getEmail() const
{
    return email;
}

inline void Customer::setEmail(const QString& newEmail)
{
    email = newEmail;
}

inline const QString& Customer::getDomain() const
{
    return domain;
}

inline void Customer::setDomain(const QString& newDomain)
{
    domain = newDomain;
}

inline const QString& Customer::getAddress() const
{
    return address;
}

inline void Customer::setAddress(const QString& newAddress)
{
    address = newAddress;
}

inline const QString& Customer::getFavorite() const
{
    return favorite;
}

inline void Customer::setFavorite(const QString& newFavorite)
{
    favorite = newFavorite;
}

inline int Customer::getAge() const
{
    return age;
}

inline void Customer::setAge(int newAge)
{
    age = newAge;
}

inline const QString& Customer::getGender() const
{
    return gender;
}

inline void Customer::setGender(const QString& newGender)
{
    gender = newGender;
}

inline const QString& Customer::getJoinDate() const
{
    return joinDate;
}

inline void Customer::setJoinDate(const QString& newJoinDate)
{
    joinDate = newJoinDate;
}

inline int Customer::getCid() const
{
    return Cid;
}

inline void Customer::setCid(int newCid)
{
    Cid = newCid;
}

typedef QList<Customer> Customer_list;



class Merchandise
{
public:
    int Mid;
    QString mname;
    int price;
    int quantity;
    QString madein;
    QString category;
    QString description;
    QString enrollDate;

public:
    Merchandise()
    {
        Mid = 0;
        price = 0;
        quantity = 0;
    }

public:
    int getMid() const;
    void setMid(int newMid);
    const QString& getMname() const;
    void setMname(const QString& newMname);
    int getPrice() const;
    void setPrice(int newPrice);
    int getQuantity() const;
    void setQuantity(int newQuantity);
    const QString& getMadein() const;
    void setMadein(const QString& newMadein);
    const QString& getCategory() const;
    void setCategory(const QString& newCategory);
    const QString& getDescription() const;
    void setDescription(const QString& newDescription);
    const QString& getEnrollDate() const;
    void setEnrollDate(const QString& newEnrollDate);
};

inline const QString& Merchandise::getMname() const
{
    return mname;
}

inline void Merchandise::setMname(const QString& newMname)
{
    mname = newMname;
}

inline int Merchandise::getPrice() const
{
    return price;
}

inline void Merchandise::setPrice(int newPrice)
{
    price = newPrice;
}

inline const QString& Merchandise::getCategory() const
{
    return category;
}

inline void Merchandise::setCategory(const QString& newCategory)
{
    category = newCategory;
}

inline const QString& Merchandise::getDescription() const
{
    return description;
}

inline void Merchandise::setDescription(const QString& newDescription)
{
    description = newDescription;
}

inline const QString& Merchandise::getEnrollDate() const
{
    return enrollDate;
}

inline void Merchandise::setEnrollDate(const QString& newEnrollDate)
{
    enrollDate = newEnrollDate;
}

inline int Merchandise::getQuantity() const
{
    return quantity;
}

inline void Merchandise::setQuantity(int newQuantity)
{
    quantity = newQuantity;
}

inline const QString& Merchandise::getMadein() const
{
    return madein;
}

inline void Merchandise::setMadein(const QString& newMadein)
{
    madein = newMadein;
}

inline int Merchandise::getMid() const
{
    return Mid;
}

inline void Merchandise::setMid(int newMid)
{
    Mid = newMid;
}

typedef QList<Merchandise> Merchandise_list;




class Purchase
{
public:
    int Pid;
    int Cid;
    int Mid;
    int buyAmount;
    QString shopDate;

public:
    Purchase()
    {
        Pid = 0;
        Cid = 0;
        Mid = 0;
        buyAmount = 0;
    }

public:
    int getPid() const;
    void setPid(int newPid);
    int getCid() const;
    void setCid(int newCid);
    int getMid() const;
    void setMid(int newMid);
    int getBuyAmount() const;
    void setBuyAmount(int newBuyAmount);
    const QString& getShopDate() const;
    void setShopDate(const QString& newShopDate);
};

inline int Purchase::getCid() const
{
    return Cid;
}

inline void Purchase::setCid(int newCid)
{
    Cid = newCid;
}

inline int Purchase::getMid() const
{
    return Mid;
}

inline void Purchase::setMid(int newMid)
{
    Mid = newMid;
}

inline int Purchase::getBuyAmount() const
{
    return buyAmount;
}

inline void Purchase::setBuyAmount(int newBuyAmount)
{
    buyAmount = newBuyAmount;
}

inline const QString& Purchase::getShopDate() const
{
    return shopDate;
}

inline void Purchase::setShopDate(const QString& newShopDate)
{
    shopDate = newShopDate;
}

inline int Purchase::getPid() const
{
    return Pid;
}

inline void Purchase::setPid(int newPid)
{
    Pid = newPid;
}

typedef QList<Purchase> Purchase_list;

#endif // GLOBAL_H







