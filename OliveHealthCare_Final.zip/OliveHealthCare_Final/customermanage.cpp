﻿#include "customermanage.h"
#include "ui_customermanage.h"
#include "dbmgr.h"
#include <QDebug>

CustomerManage::CustomerManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CustomerManage)
{
    ui->setupUi(this);

    QStringList headerList;
    headerList << tr("CID")                // 회원 Key
               << tr("NAME")               // 회원 이름
               << tr("PHONE NUMBER")       // 회원 전화 번호
               << tr("EMAIL")              // 회원 이메일 주소
               << tr("DOMAIN")             // 회원 도메인 주소
               << tr("ADDRESS")            // 회원 거주지 주소
               << tr("FAVORITE")           // 회원 선호 항목
               << tr("AGE")                // 회원 연령
               << tr("GENDER")             // 회원 성별
               << tr("JOINDATE");          // 회원 가입 날짜

    // 헤더 정보 적용
    ui->tableWidget->setColumnCount(headerList.size());
    ui->tableWidget->setHorizontalHeaderLabels(headerList);
    ui->tableWidget->resizeColumnsToContents();
    ui->tableWidget_search->setColumnCount(headerList.size());
    ui->tableWidget_search->setHorizontalHeaderLabels(headerList);
    ui->tableWidget_search->resizeColumnsToContents();

    // load customer db
    loadList();

    // ui stylesheet 적용부분
    ui->tableWidget->setStyleSheet("QWidget {background-color: #333333;color: #ffffff;}"
                                   "QHeaderView::section {background-color: #646464;border: 1px solid #ffffff;font-size: 10pt;}"
                                   "QTableWidget {gridline-color: #ffffff;font-size: 9pt;}"
                                   "QTableWidget QTableCornerButton::section {background-color: #646464;border: 1px solid #fffff8;}");
//    ui->idLabel->setStyleSheet("QLabel{background-color:rgb(255, 128, 255); color:rgb(255, 0, 0);}");
//    ui->idLineEdit->setStyleSheet("QLineEdit{background-color:rgb(255, 0, 255); color:rgb(0, 255, 0);}");

    //
}

CustomerManage::~CustomerManage()
{
    delete ui;
}

void CustomerManage::loadList()
{
    Customer_list list = DBMgr::getInstance()->getCustomerList();
    foreach (Customer info, list)
    {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 0, new QTableWidgetItem(QString::number(info.getCid())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 1, new QTableWidgetItem(info.getName()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 2, new QTableWidgetItem(info.getPhoneNumber()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 3, new QTableWidgetItem(info.getEmail()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 4, new QTableWidgetItem(info.getDomain()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 5, new QTableWidgetItem(info.getAddress()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 6, new QTableWidgetItem(info.getFavorite()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 7, new QTableWidgetItem(QString::number(info.getAge())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 8, new QTableWidgetItem(info.getGender()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 9, new QTableWidgetItem(info.getJoinDate()));
    }

    ui->tableWidget->resizeColumnsToContents();
}

void CustomerManage::clearAllList()
{
    qDebug() << __FUNCTION__;

    while (ui->tableWidget->rowCount() > 0)
    {
        ui->tableWidget->removeRow(0);
    }
}

Customer_list CustomerManage::getTableList()
{
    Customer_list list;

    for (int i = 0; i < ui->tableWidget->rowCount(); ++i)
    {
        Customer cInfo;
        QTableWidgetItem* _item;
        _item = ui->tableWidget->item(i, 0);  if (_item) { cInfo.setCid(_item->text().toInt()); }
        _item = ui->tableWidget->item(i, 1);  if (_item) { cInfo.setName(_item->text()); }
        _item = ui->tableWidget->item(i, 2);  if (_item) { cInfo.setPhoneNumber(_item->text()); }
        _item = ui->tableWidget->item(i, 3);  if (_item) { cInfo.setEmail(_item->text()); }
        _item = ui->tableWidget->item(i, 4);  if (_item) { cInfo.setDomain(_item->text()); }
        _item = ui->tableWidget->item(i, 5);  if (_item) { cInfo.setAddress(_item->text()); }
        _item = ui->tableWidget->item(i, 6);  if (_item) { cInfo.setFavorite(_item->text()); }
        _item = ui->tableWidget->item(i, 7);  if (_item) { cInfo.setAge(_item->text().toInt()); }
        _item = ui->tableWidget->item(i, 8);  if (_item) { cInfo.setGender(_item->text()); }
        _item = ui->tableWidget->item(i, 9);  if (_item) { cInfo.setJoinDate(_item->text()); }

        list.append(cInfo);
    }

    return list;
}

void CustomerManage::on_addPushButton_clicked()
{
    qDebug() << __FUNCTION__;

    // 회원 키값 정보를 저장할 리스트 -> 구매 클래스에서 활용
    //QList<int> CidAddList;

    // 회원 이름 정보를 저장할 리스트 -> 채팅 서버에서 활용
    //QList<QString> cNameAddList;

    // 회원별 Key 값을 생성 및 부여, 항목별로 전달될 자료형을 선정한다
    int Cid = makeCid();
    QString name, phoneNumber, email, domain, address, favorite, gender, joinDate;
    int age;

    // idLineEdit 에 회원 정보 Key 값을 String 형식으로 반환
    ui->idLineEdit->setText(QString::number(Cid));

    // nameLineEdit ui 에 입력된 텍스트를 name 항목으로 반환
    name = ui->nameLineEdit->text();

    // phoneNumberLineEdit ui 에 입력된 텍스트를 phoneNumber 항목으로 반환
    phoneNumber = ui->phoneNumberLineEdit->text();

    // emailLineEdit ui 에 입력된 텍스트를 email 항목으로 반환
    email = ui->emailLineEdit->text();

    // domainComboBox ui 에 입력된 텍스트를 domain 항목으로 반환
    domain = ui->domainComboBox->currentText();

    // favoriteComboBox ui 에 입력된 텍스트를 favorite 항목으로 반환
    favorite = ui->favoriteComboBox->currentText();

    // addressLineEdit ui 에 입력된 텍스트를 address 항목으로 반환
    address = ui->addressLineEdit->text();

    // ageSpinBox ui 에 입력된 값를 age 항목으로 반환
    age = ui->ageSpinBox->value();

    // male, female Button ui 에서 선택한 정보를 gender 항목으로 반환
    if(ui->maleButton->isChecked())
    {
        gender = ui->maleButton->text();
    }
    else
    {
        gender = ui->femaleButton->text();
    }

    // dateEdit ui 에 입력된 값를 joinDate 항목으로 반환
    //joinDate = ui->dateEdit->date().toString();
    joinDate = ui->dateEdit->date().toString("yyyyMMdd");

    qDebug() << __FUNCTION__
             << "Cid: " << Cid
             << "name: " << name
             << "phoneNumber: " << phoneNumber
             << "email: " << email
             << "domain: " << domain
             << "address: " << address
             << "favorite: " << favorite
             << "gender: " << gender
             << "joinDate: " << joinDate
             << "age: " << age;

    // DB에 기록
    Customer info;
    info.setCid(Cid);
    info.setName(name);
    info.setPhoneNumber(phoneNumber);
    info.setEmail(email);
    info.setDomain(domain);
    info.setAddress(address);
    info.setFavorite(favorite);
    info.setAge(age);
    info.setGender(gender);
    info.setJoinDate(joinDate);

    DBMgr::getInstance()->addCustomer(info);     // DB에 추가
    emit clientAdded(Cid, name);
    // reload
    on_refreshPushButton_clicked();
}


void CustomerManage::on_modifyPushButton_clicked()
{
    if (ui->idLineEdit->text().isEmpty())
        return;

    int Cid = ui->idLineEdit->text().toInt();

    QString name, phoneNumber, email, domain, address, favorite, gender, joinDate;
    int age;

    // nameLineEdit ui 에 입력된 텍스트를 name 항목으로 반환
    name = ui->nameLineEdit->text();

    // phoneNumberLineEdit ui 에 입력된 텍스트를 phoneNumber 항목으로 반환
    phoneNumber = ui->phoneNumberLineEdit->text();

    // emailLineEdit ui 에 입력된 텍스트를 email 항목으로 반환
    email = ui->emailLineEdit->text();

    // domainComboBox ui 에 입력된 텍스트를 domain 항목으로 반환
    domain = ui->domainComboBox->currentText();

    // favoriteComboBox ui 에 입력된 텍스트를 favorite 항목으로 반환
    favorite = ui->favoriteComboBox->currentText();

    // addressLineEdit ui 에 입력된 텍스트를 address 항목으로 반환
    address = ui->addressLineEdit->text();

    // ageSpinBox ui 에 입력된 값를 age 항목으로 반환
    age = ui->ageSpinBox->value();

    // male, female Button ui 에서 선택한 정보를 gender 항목으로 반환
    if(ui->maleButton->isChecked())
    {
        gender = ui->maleButton->text();
    }
    else
    {
        gender = ui->femaleButton->text();
    }

    // dateEdit ui 에 입력된 값를 joinDate 항목으로 반환
    //joinDate = ui->dateEdit->date().toString();
    joinDate = ui->dateEdit->date().toString("yyyyMMdd");

    qDebug() << __FUNCTION__
             << "Cid: " << Cid
             << "name: " << name
             << "phoneNumber: " << phoneNumber
             << "email: " << email
             << "domain: " << domain
             << "address: " << address
             << "favorite: " << favorite
             << "gender: " << gender
             << "joinDate: " << joinDate
             << "age: " << age;

    Customer info;
    info.setCid(Cid);
    info.setName(name);
    info.setPhoneNumber(phoneNumber);
    info.setEmail(email);
    info.setDomain(domain);
    info.setAddress(address);
    info.setFavorite(favorite);
    info.setAge(age);
    info.setGender(gender);
    info.setJoinDate(joinDate);

    DBMgr::getInstance()->updateCustomer(info);     // DB update

    // reload
    on_refreshPushButton_clicked();
}

void CustomerManage::on_deletePushButton_clicked()
{
    QItemSelectionModel *select = ui->tableWidget->selectionModel();
    bool isSelect = select->hasSelection();                  //check if has selection
    if (!isSelect)
        return;

    QModelIndexList selectedList = select->selectedRows();   // return selected row(s)

    qDebug() << __FUNCTION__ << isSelect << selectedList;
    for(int i=0; i< selectedList.count(); i++)
    {
        QModelIndex index = selectedList.at(i);
        QTableWidgetItem* delItem = ui->tableWidget->item(index.row(), 0);
        QString Cid = delItem->text();
        DBMgr::getInstance()->deleteCustomer(Cid);
        qDebug() << __FUNCTION__ << "delete Cid: " << Cid;

        ui->tableWidget->removeRow(index.row());            // 선택된 row 테이블에서 삭제
    }
}


void CustomerManage::on_refreshPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    // list all clear
    clearAllList();

    // load all list
    loadList();
}

void CustomerManage::on_searchPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    QString searchType = ui->searchComboBox->currentText();
    QString searchText = ui->searchLineEdit->text();
    qDebug() << __FUNCTION__ << searchType << searchText;

    if (searchText.isEmpty())
        return;

    // clear all search list
    while (ui->tableWidget_search->rowCount() > 0)
    {
        ui->tableWidget_search->removeRow(0);
    }

    Customer_list list = DBMgr::getInstance()->getCustomerList_search(searchType, searchText);      // db search

    foreach (Customer info, list)
    {
        ui->tableWidget_search->insertRow(ui->tableWidget_search->rowCount());
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 0, new QTableWidgetItem(QString::number(info.getCid())));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 1, new QTableWidgetItem(info.getName()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 2, new QTableWidgetItem(info.getPhoneNumber()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 3, new QTableWidgetItem(info.getEmail()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 4, new QTableWidgetItem(info.getDomain()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 5, new QTableWidgetItem(info.getAddress()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 6, new QTableWidgetItem(info.getFavorite()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 7, new QTableWidgetItem(QString::number(info.getAge())));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 8, new QTableWidgetItem(info.getGender()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 9, new QTableWidgetItem(info.getJoinDate()));
    }

    ui->tableWidget_search->resizeColumnsToContents();
}


void CustomerManage::on_tableWidget_clicked(const QModelIndex &index)
{
    qDebug() << __FUNCTION__;
    // 항목별 데이터를 순서 및 자료형에 따라 인덱스로 보낸다
    int Cid = ui->tableWidget->item(index.row(), 0)->text().toInt();
    QString name = ui->tableWidget->item(index.row(), 1)->text();
    QString phoneNumber = ui->tableWidget->item(index.row(), 2)->text();
    QString email = ui->tableWidget->item(index.row(), 3)->text();
    QString domain = ui->tableWidget->item(index.row(), 4)->text();
    QString address = ui->tableWidget->item(index.row(), 5)->text();
    QString favorite = ui->tableWidget->item(index.row(), 6)->text();
    int age = ui->tableWidget->item(index.row(), 7)->text().toInt();
    QString gender = ui->tableWidget->item(index.row(), 8)->text();
    QDate joinDate = QDate::fromString(ui->tableWidget->item(index.row(), 9)->text(), "yyyyMMdd");

    // 각 ui 에 입력된 정보를 항목별로 저장한다
    ui->idLineEdit->setText(QString::number(Cid));
    ui->nameLineEdit->setText(name);
    ui->phoneNumberLineEdit->setText(phoneNumber);
    ui->emailLineEdit->setText(email);
    ui->domainComboBox->setCurrentText(domain);
    ui->addressLineEdit->setText(address);
    ui->favoriteComboBox->setCurrentText(favorite);
    ui->ageSpinBox->setValue(age);

    if(ui->maleButton->isChecked())
    {
        ui->maleButton->setText(gender);
    } else
    {
        ui->femaleButton->setText(gender);
    }
    ui->dateEdit->setDate(joinDate);
}

int CustomerManage::makeCid()
{
    qDebug() << __FUNCTION__;
    int rtn = 0;
    Customer_list list = DBMgr::getInstance()->getCustomerList();
    if (list.size() < 1)
        return 0;
    Customer info = list.at(list.count()-1);
    rtn = info.getCid()+1;
    return rtn;
}
