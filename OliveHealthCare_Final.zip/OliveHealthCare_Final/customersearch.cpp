﻿#include "customersearch.h"
#include "ui_customersearch.h"
#include "dbmgr.h"
#include <QDebug>

CustomerSearch::CustomerSearch(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CustomerSearch)
{
    ui->setupUi(this);

    QStringList headerList;
    headerList << tr("CID")                // 회원 Key
               << tr("NAME")               // 회원 이름
               << tr("PHONE NUMBER")       // 회원 전화 번호
               << tr("EMAIL")              // 회원 이메일 주소
               << tr("DOMAIN")             // 회원 도메인 주소
               << tr("ADDRESS")            // 회원 거주지 주소
               << tr("FAVORITE")           // 회원 선호 항목
               << tr("AGE")                // 회원 연령
               << tr("GENDER")             // 회원 성별
               << tr("JOINDATE");          // 회원 가입 날짜

    // 헤더 정보 적용
    ui->tableWidget->setColumnCount(headerList.size());
    ui->tableWidget->setHorizontalHeaderLabels(headerList);
    ui->tableWidget->resizeColumnsToContents();
}

CustomerSearch::~CustomerSearch()
{
    delete ui;
}

void CustomerSearch::loadList()
{
    qDebug() << __FUNCTION__;
    QString favoriteType;
    if (ui->medicalPushButton->isChecked())
        favoriteType = "Medical";
    if (ui->healthpushButton->isChecked())
        favoriteType = "Health";
    if (ui->dietPushButton->isChecked())
        favoriteType = "Diet";

    Customer_list list = DBMgr::getInstance()->getCustomerList_search("favorite", favoriteType);
    foreach (Customer info, list)
    {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 0, new QTableWidgetItem(QString::number(info.getCid())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 1, new QTableWidgetItem(info.getName()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 2, new QTableWidgetItem(info.getPhoneNumber()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 3, new QTableWidgetItem(info.getEmail()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 4, new QTableWidgetItem(info.getDomain()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 5, new QTableWidgetItem(info.getAddress()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 6, new QTableWidgetItem(info.getFavorite()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 7, new QTableWidgetItem(QString::number(info.getAge())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 8, new QTableWidgetItem(info.getGender()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 9, new QTableWidgetItem(info.getJoinDate()));
    }

    ui->tableWidget->resizeColumnsToContents();
}

void CustomerSearch::clearAllList()
{
    qDebug() << __FUNCTION__;
    while (ui->tableWidget->rowCount() > 0)
    {
        ui->tableWidget->removeRow(0);
    }
}

void CustomerSearch::on_medicalPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

void CustomerSearch::on_healthpushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

void CustomerSearch::on_dietPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    clearAllList();
    loadList();
}

