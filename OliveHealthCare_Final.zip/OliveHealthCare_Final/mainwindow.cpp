﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "customermanage.h"
#include "customersearch.h"
#include "merchandisemanage.h"
#include "merchandisesearch.h"
#include "purchasemanage.h"
#include "purchasesearch.h"
#include "chattingserver.h"
#include "chattingclient.h"
#include <QButtonGroup>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    resize(1020, 800);
    ui->stackedWidget->setCurrentIndex(0);      // 첫화면 전환 (customerManage)
    //ui->statusbar->hide();                      // 하단 status hide

    customerManage = new CustomerManage(this);
    customerSearch = new CustomerSearch(this);
    merchandiseManage = new MerchandiseManage(this);
    merchandiseSearch = new MerchandiseSearch(this);
    purchaseManage = new PurchaseManage(this);
    purchaseSearch = new PurchaseSearch(this);
    chattingServer = new ChattingServer(this);
    chattingClient = new ChattingClient(this);

    // 각 페이지 테이블 정보 불러오는 시그널 슬롯
    connect(purchaseManage, SIGNAL(getCustomerTable()), this, SLOT(slot_getCustomerTable_from_purchaseManage()));
    connect(purchaseManage, SIGNAL(getMerchandiseTable()), this, SLOT(slot_getMerchandiseTable_from_purchaseManage()));
    connect(customerManage, SIGNAL(clientAdded(int, Qstring)), chattingServer, SLOT(addClient(int,QString)));
    ui->verticalLayout_customerManage->addWidget(customerManage);       // 레이아웃에 customerManage 추가
    ui->verticalLayout_customerSearch->addWidget(customerSearch);       // 레이아웃에 customerSearch 추가
    ui->verticalLayout_merchandiseManage->addWidget(merchandiseManage); // 레이아웃에 merchandiseManage 추가
    ui->verticalLayout_merchandiseSearch->addWidget(merchandiseSearch); // 레이아웃에 merchandiseSearch 추가
    ui->verticalLayout_purchaseManage->addWidget(purchaseManage);       // 레이아웃에 purchaseManage 추가
    ui->verticalLayout_purchaseSearch->addWidget(purchaseSearch);       // 레이아웃에 purchaseSearch 추가
    ui->verticalLayout_chattingServer->addWidget(chattingServer);       // 레이아웃에 chattingServer 추가
    ui->verticalLayout_chattingClient->addWidget(chattingClient);       // 레이아웃에 chattingClient 추가


    ////////////////////////////////////////////////////////////////////////////////////////////////////
    // UI 변경 (stylesheet 적용)
    // stylesheet 는 css 기반으로 적용 가능
    // 참고 : https://doc.qt.io/qt-6/stylesheet-examples.html

    // 메인 전체를 덮고있는 box
    ui->groupBox_main_1->setStyleSheet("QGroupBox#groupBox_main_1{background-color:rgb(15, 15, 15); border:none;}");      // groupBox_main ui 변경

    //  상단 버튼이 모여있는 box
    ui->groupBox_tab->setStyleSheet("QGroupBox#groupBox_tab{background-color:rgb(255, 128, 0); border:none; border-radius:5px;}"      // groupBox_tab ui 변경
                                    "QPushButton{background-color: rgb(0,0,0); border:none; border-radius:5px;}"      // groupBox 안에 포함된 버튼 모두에게 ui 변경 적용
                                    "QPushButton:checked{background-color: rgb(255, 128, 0);}"
                                    "QPushButton:hover{background-color: rgb(100, 100, 100);}"
                                    "QPushButton:pressed{background-color: rgb(77, 77, 77);}");

    // 버튼 각각 개별적으로 적용하는 코드
//    ui->pushButton_color1->setStyleSheet("QPushButton{background-color: rgb(255, 160, 64); border:1px solid black; color:rgb(255,255,255);}");
//    ui->pushButton_color2->setStyleSheet("QPushButton{background-color: rgb(128, 255, 192); border:1px solid black; color:rgb(255,255,255);}");
//    ui->pushButton_color3->setStyleSheet("QPushButton{background-color: rgb(85, 85, 85); border:1px solid black; color:rgb(255,255,255);}");

    // 상단 버튼 개별적으로 스타일 바꾸기
//    ui->pushButton_customerManage->setStyleSheet("QPushButton{background-color: rgb(0, 0, 0); border:none; border-radius:5px;}"
//                                                 "QPushButton:checked{background-color: rgb(255, 128, 255);}"
//                                                 "QPushButton:hover{background-color: rgb(73, 73, 73);}"
//                                                 "QPushButton:pressed{background-color: rgb(32, 128, 208);}");
//    ui->pushButton_customerSearch->setStyleSheet("QPushButton{background-color: rgb(128, 0, 128); border:none; border-radius:5px;}"
//                                                 "QPushButton:checked{background-color: rgb(255, 192, 192);}"
//                                                 "QPushButton:hover{background-color: rgb(0, 255, 0);}"
//                                                 "QPushButton:pressed{background-color: rgb(128, 128, 0);}");
    ////////////////////////////////////////////////////////////////////////////////////////////////////

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_customerManage_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);      // 화면전환 (customerManage)
}

void MainWindow::on_pushButton_customerSearch_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);      // 화면전환 (customerSearch)
    customerSearch->clearAllList();
    customerSearch->loadList();
}

void MainWindow::on_pushButton_merchandiseManage_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);      // 화면전환 (merchandiseManage)
}

void MainWindow::on_pushButton_merchandiseSearch_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);      // 화면전환 (merchandiseSearch)
    merchandiseSearch->clearAllList();
    merchandiseSearch->loadList();
}

void MainWindow::on_pushButton_purchaseManage_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);      // 화면전환 (purchaseManage)
}

void MainWindow::on_pushButton_purchaseSearch_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);      // 화면전환 (purchaseSearch)
    purchaseSearch->clearAllList();
    purchaseSearch->loadList();
}

void MainWindow::on_pushButton_chatServer_clicked()
{
    ui->stackedWidget->setCurrentIndex(6);      // 화면전환 (chatServer)
}

void MainWindow::on_pushButton_customerChat_clicked()
{
    ui->stackedWidget->setCurrentIndex(7);      // 화면전환 (customerChat)
}

void MainWindow::on_pushButton_quit_clicked()
{
    qApp->quit();       // 종료
}


void MainWindow::on_pushButton_color1_clicked()
{
    ui->groupBox_main_1->setStyleSheet("QGroupBox#groupBox_main_1{background-color:rgb(255, 160, 64); border:none;}");      // groupBox_main_1 ui 변경
}


void MainWindow::on_pushButton_color2_clicked()
{
    ui->groupBox_main_1->setStyleSheet("QGroupBox#groupBox_main_1{background-color:rgb(128, 255, 192); border:none;}");      // groupBox_main_1 ui 변경
}


void MainWindow::on_pushButton_color3_clicked()
{
    ui->groupBox_main_1->setStyleSheet("QGroupBox#groupBox_main_1{background-color:rgb(85, 85, 85); border:none;}");      // groupBox_main_1 ui 변경
}

void MainWindow::slot_getCustomerTable_from_purchaseManage()
{
    qDebug() << __FUNCTION__;
    Customer_list list = customerManage->getTableList();
    purchaseManage->setCustomerTableList(list);
}

void MainWindow::slot_getMerchandiseTable_from_purchaseManage()
{
    qDebug() << __FUNCTION__;
    Merchandise_list list = merchandiseManage->getTableList();
    purchaseManage->setMerchandiseTableList(list);
}


