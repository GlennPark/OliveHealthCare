﻿#ifndef CUSTOMERMANAGE_H
#define CUSTOMERMANAGE_H

#include <QWidget>
#include "global.h"

namespace Ui {
class CustomerManage;
}

class CustomerManage : public QWidget
{
    Q_OBJECT

public:
    explicit CustomerManage(QWidget *parent = nullptr);
    ~CustomerManage();

    void loadList();                       // 리스트 불러오기
    void clearAllList();                   // 리스트 모두 제거
    Customer_list getTableList();
signals:
    void clientAdded(int, QString);

private slots:
    void on_addPushButton_clicked();            // 추가버튼
    void on_modifyPushButton_clicked();         // 수정버튼
    void on_deletePushButton_clicked();         // 리스트에 선택된 정보 삭제
    void on_refreshPushButton_clicked();        // DB에서 정보 다시가져오기
    void on_searchPushButton_clicked();         // 검색버튼
    void on_tableWidget_clicked(const QModelIndex &index);      // list 클릭

private:
    Ui::CustomerManage *ui;

private:
    // 회원 키값 변수
    int makeCid();
};

#endif // CUSTOMERMANAGE_H
