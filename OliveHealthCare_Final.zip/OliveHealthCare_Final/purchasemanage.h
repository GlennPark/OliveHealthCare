﻿#ifndef PURCHASEMANAGE_H
#define PURCHASEMANAGE_H

#include <QWidget>
#include "global.h"

namespace Ui {
class PurchaseManage;
}

class PurchaseManage : public QWidget
{
    Q_OBJECT

public:
    explicit PurchaseManage(QWidget *parent = nullptr);
    ~PurchaseManage();

    void loadList();                       // 리스트 불러오기
    void clearAllList();                   // 리스트 모두 제거

    void setCustomerTableList(Customer_list cList);
    void setMerchandiseTableList(Merchandise_list mList);

private slots:
    void on_addPushButton_clicked();        // 추가버튼
    void on_refreshPushButton_clicked();    // 수정버튼
    void on_deletePushButton_clicked();     // 리스트에 선택된 정보 삭제
    void on_searchPushButton_clicked();     // 검색버튼

    void on_tableWidget_clicked(const QModelIndex &index);
    void on_pushButton_get_customer_table_clicked();
    void on_pushButton_get_merchandise_table_clicked();

private:
    Ui::PurchaseManage *ui;

private:
    // 구매 키값 변수
    int makePid();

signals:
    // 각 페이지 테이블 데이터 요청 시그널
    void getCustomerTable();
    void getMerchandiseTable();
};

#endif // PURCHASEMANAGE_H
