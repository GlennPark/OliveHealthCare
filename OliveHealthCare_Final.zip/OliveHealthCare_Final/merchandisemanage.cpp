﻿#include "merchandisemanage.h"
#include "ui_merchandisemanage.h"
#include "dbmgr.h"
#include <QDebug>

MerchandiseManage::MerchandiseManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MerchandiseManage)
{
    ui->setupUi(this);

    QStringList headerList;
    headerList << tr("MID")                 // 제품 Key
               << tr("MNAME")               // 제품명
               << tr("PRICE")               // 제품 가격
               << tr("QUANTITY")            // 제품 수량
               << tr("MADEIN")              // 제품 생산국가
               << tr("CATEGORY")            // 제품 유형
               << tr("DESCRIPTION")         // 제품 설명
               << tr("ENROLLDATE");         // 제품 등록 일자

    // 헤더 정보 적용
    ui->tableWidget->setColumnCount(headerList.size());
    ui->tableWidget->setHorizontalHeaderLabels(headerList);
    ui->tableWidget->resizeColumnsToContents();
    ui->tableWidget_search->setColumnCount(headerList.size());
    ui->tableWidget_search->setHorizontalHeaderLabels(headerList);
    ui->tableWidget_search->resizeColumnsToContents();

    // load merchandise db
    loadList();
}

MerchandiseManage::~MerchandiseManage()
{
    delete ui;
}

void MerchandiseManage::loadList()
{
    qDebug() << __FUNCTION__;
    Merchandise_list list = DBMgr::getInstance()->getMerchandiseList();
    foreach (Merchandise info, list)
    {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 0, new QTableWidgetItem(QString::number(info.getMid())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 1, new QTableWidgetItem(info.getMname()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 2, new QTableWidgetItem(QString::number(info.getPrice())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 3, new QTableWidgetItem(QString::number(info.getQuantity())));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 4, new QTableWidgetItem(info.getMadein()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 5, new QTableWidgetItem(info.getCategory()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 6, new QTableWidgetItem(info.getDescription()));
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1, 7, new QTableWidgetItem(info.getEnrollDate()));
    }

    ui->tableWidget->resizeColumnsToContents();
}

void MerchandiseManage::clearAllList()
{
    qDebug() << __FUNCTION__;

    while (ui->tableWidget->rowCount() > 0)
    {
        ui->tableWidget->removeRow(0);
    }
}

Merchandise_list MerchandiseManage::getTableList()
{
    Merchandise_list list;

    for (int i = 0; i < ui->tableWidget->rowCount(); ++i)
    {
        Merchandise mInfo;
        QTableWidgetItem* _item;
        _item = ui->tableWidget->item(i, 0);  if (_item) { mInfo.setMid(_item->text().toInt()); }
        _item = ui->tableWidget->item(i, 1);  if (_item) { mInfo.setMname(_item->text()); }
        _item = ui->tableWidget->item(i, 2);  if (_item) { mInfo.setPrice(_item->text().toInt()); }
        _item = ui->tableWidget->item(i, 3);  if (_item) { mInfo.setQuantity(_item->text().toInt()); }
        _item = ui->tableWidget->item(i, 4);  if (_item) { mInfo.setMadein(_item->text()); }
        _item = ui->tableWidget->item(i, 5);  if (_item) { mInfo.setCategory(_item->text()); }
        _item = ui->tableWidget->item(i, 6);  if (_item) { mInfo.setDescription(_item->text()); }
        _item = ui->tableWidget->item(i, 7);  if (_item) { mInfo.setEnrollDate(_item->text()); }

        list.append(mInfo);
    }

    return list;
}

void MerchandiseManage::on_addPushButton_clicked()
{
    qDebug() << __FUNCTION__;

    // 제품 키값 정보를 저장할 리스트 -> 구매 클래스에서 활용
    //QList<int> MidAddList;

    // 제품별 Key 값을 생성 및 부여, 항목별로 전달될 자료형을 선정한다
    int Mid = makeMid( );
    QString mname, madein, category, description, enrollDate;
    int price, quantity;

    // idLineEdit 에 제품 정보 Key 값을 String 형식으로 반환
    ui->idLineEdit->setText(QString::number(Mid));

    // nameLineEdit ui 에 입력된 텍스트를 mname 항목으로 반환
    mname = ui->nameLineEdit->text();

    // priceLineEdit ui 에 입력된 값을 price 항목으로 반환
    price = ui->priceLineEdit->text().toInt();

    // quantitySpinBox ui 에 입력된 값을 quantity 항목으로 반환
    quantity = ui->quantitySpinBox->value();

    // madeinComboBox ui 에 입력된 텍스트를 madein 항목으로 반환
    madein = ui->madeinComboBox->currentText();

    // categoryComboBox ui 에 입력된 텍스트를 category 항목으로 반환
    category = ui->categoryComboBox->currentText();

    // textEdit ui 에 입력된 텍스트를 description 에 저장
    description = ui->textEdit->toPlainText();

    // dateEdit ui 에 입력된 값를 enrollDate 항목으로 반환
    //enrollDate = ui->dateEdit->date().toString();
    enrollDate = ui->dateEdit->date().toString("yyyyMMdd");

    qDebug() << __FUNCTION__
             << "Mid: "   << Mid
             << "mname: " << mname
             << "price: " << price
             << "quantity: " << quantity
             << "madein: " << madein
             << "category: " << category
             << "description: " << description
             << "enrollDate: " << enrollDate;

    // DB에 기록
    Merchandise info;
    info.setMid(Mid);
    info.setMname(mname);
    info.setPrice(price);
    info.setQuantity(quantity);
    info.setMadein(madein);
    info.setCategory(category);
    info.setDescription(description);
    info.setEnrollDate(enrollDate);

    DBMgr::getInstance()->addMerchandise(info);     // DB에 추가

    // reload
    on_refreshPushButton_clicked();
}

void MerchandiseManage::on_modifyPushButton_clicked()
{
    qDebug() << __FUNCTION__;

    if (ui->idLineEdit->text().isEmpty())
        return;

    int Mid = ui->idLineEdit->text().toInt();
    QString mname, madein, category, description, enrollDate;
    int price, quantity;

    // idLineEdit 에 제품 정보 Key 값을 String 형식으로 반환
    ui->idLineEdit->setText(QString::number(Mid));

    // nameLineEdit ui 에 입력된 텍스트를 mname 항목으로 반환
    mname = ui->nameLineEdit->text();

    // priceLineEdit ui 에 입력된 값을 price 항목으로 반환
    price = ui->priceLineEdit->text().toInt();

    // quantitySpinBox ui 에 입력된 값을 quantity 항목으로 반환
    quantity = ui->quantitySpinBox->value();

    // madeinComboBox ui 에 입력된 텍스트를 madein 항목으로 반환
    madein = ui->madeinComboBox->currentText();

    // categoryComboBox ui 에 입력된 텍스트를 category 항목으로 반환
    category = ui->categoryComboBox->currentText();

    // textEdit ui 에 입력된 텍스트를 description 에 저장
    description = ui->textEdit->toPlainText();

    // dateEdit ui 에 입력된 값를 enrollDate 항목으로 반환
    //enrollDate = ui->dateEdit->date().toString();
    enrollDate = ui->dateEdit->date().toString("yyyyMMdd");

    qDebug() << __FUNCTION__
             << "Mid: "   << Mid
             << "mname: " << mname
             << "price: " << price
             << "quantity: " << quantity
             << "madein: " << madein
             << "category: " << category
             << "description: " << description
             << "enrollDate: " << enrollDate;

    // DB에 기록
    Merchandise info;
    info.setMid(Mid);
    info.setMname(mname);
    info.setPrice(price);
    info.setQuantity(quantity);
    info.setMadein(madein);
    info.setCategory(category);
    info.setDescription(description);
    info.setEnrollDate(enrollDate);

    DBMgr::getInstance()->updateMerchandise(info);     // DB update

    // reload
    on_refreshPushButton_clicked();
}

void MerchandiseManage::on_deletePushButton_clicked()
{
    qDebug() << __FUNCTION__;
    QItemSelectionModel *select = ui->tableWidget->selectionModel();
    bool isSelect = select->hasSelection();                  //check if has selection
    if (!isSelect)
        return;

    QModelIndexList selectedList = select->selectedRows();   // return selected row(s)

    qDebug() << __FUNCTION__ << isSelect << selectedList;
    for(int i=0; i< selectedList.count(); i++)
    {
        QModelIndex index = selectedList.at(i);
        QTableWidgetItem* delItem = ui->tableWidget->item(index.row(), 0);
        QString Mid = delItem->text();
        DBMgr::getInstance()->deleteMerchandise(Mid);
        qDebug() << __FUNCTION__ << "delete Mid: " << Mid;

        ui->tableWidget->removeRow(index.row());            // 선택된 row 테이블에서 삭제
    }
}

void MerchandiseManage::on_refreshPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    // list all clear
    clearAllList();

    // load all list
    loadList();
}

void MerchandiseManage::on_searchPushButton_clicked()
{
    qDebug() << __FUNCTION__;
    QString searchType = ui->searchComboBox->currentText();
    QString searchText = ui->searchLineEdit->text();
    qDebug() << __FUNCTION__ << searchType << searchText;

    if (searchText.isEmpty())
        return;

    // clear all search list
    while (ui->tableWidget_search->rowCount() > 0)
    {
        ui->tableWidget_search->removeRow(0);
    }

    Merchandise_list list = DBMgr::getInstance()->getMerchandiseList_search(searchType, searchText);        // db search
    foreach (Merchandise info, list)
    {
        ui->tableWidget_search->insertRow(ui->tableWidget_search->rowCount());
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 0, new QTableWidgetItem(QString::number(info.getMid())));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 1, new QTableWidgetItem(info.getMname()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 2, new QTableWidgetItem(QString::number(info.getPrice())));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 3, new QTableWidgetItem(QString::number(info.getQuantity())));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 4, new QTableWidgetItem(info.getMadein()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 5, new QTableWidgetItem(info.getCategory()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 6, new QTableWidgetItem(info.getDescription()));
        ui->tableWidget_search->setItem(ui->tableWidget_search->rowCount()-1, 7, new QTableWidgetItem(info.getEnrollDate()));
    }

    ui->tableWidget_search->resizeColumnsToContents();
}

void MerchandiseManage::on_tableWidget_clicked(const QModelIndex &index)
{
    qDebug() << __FUNCTION__;

    // 항목별 데이터를 순서 및 자료형에 따라 인덱스로 보낸다
    int Mid = ui->tableWidget->item(index.row(), 0)->text().toInt();
    QString mname = ui->tableWidget->item(index.row(), 1)->text();
    QString price = ui->tableWidget->item(index.row(), 2)->text();
    int quantity = ui->tableWidget->item(index.row(), 3)->text().toInt();
    QString madein = ui->tableWidget->item(index.row(), 4)->text();
    QString category = ui->tableWidget->item(index.row(), 5)->text();
    QString description = ui->tableWidget->item(index.row(), 6)->text();
    QDate enrollDate = QDate::fromString(ui->tableWidget->item(index.row(), 7)->text(), "yyyyMMdd");

    // 각 ui 에 입력된 정보를 항목별로 저장한다
    ui->idLineEdit->setText(QString::number(Mid));
    ui->nameLineEdit->setText(mname);
    ui->priceLineEdit->setText(price);
    ui->quantitySpinBox->setValue(quantity);
    ui->madeinComboBox->setCurrentText(madein);
    ui->categoryComboBox->setCurrentText(category);
    ui->textEdit->setText(description);
    ui->dateEdit->setDate(enrollDate);
}

int MerchandiseManage::makeMid()
{
    qDebug() << __FUNCTION__;
    int rtn = 0;
    Merchandise_list list = DBMgr::getInstance()->getMerchandiseList();
    if (list.size() < 1)
        return 0;
    Merchandise info = list.at(list.count()-1);
    rtn = info.getMid()+1;
    return rtn;
}
